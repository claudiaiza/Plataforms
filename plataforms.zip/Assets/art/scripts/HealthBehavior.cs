using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class HealthBehavior : MonoBehaviour
{
    [SerializeField]
    private float maxhealth;

    [SerializeField]
    private float health;

    public UnityEvent<float> OnChangeHealth;
    public UnityEvent OnDie;

    public bool IsDead;

    private void Start()
    {
        health = maxhealth;
        OnChangeHealth.Invoke(health);

        IsDead = false;
    }


    public float GetMaxHealth()
    {
        return maxhealth;
    }

    public float GetCurrenthealth()
    {
        return health;
    }

    public void Hurt(float damage)
    {
        health -= damage;
        if (health <= 0)
        {
            OnDie.Invoke();
            health = 0;
            // IsDead = true;

        }
            
        OnChangeHealth.Invoke(health);
    }

    public void Heal(int heal)
    {
        health += heal;
        if (health > maxhealth)
        {
            health = maxhealth;
        }
           
        OnChangeHealth.Invoke(health);
    }

    public void RestartLifes()
    {
        health = maxhealth;
    }
}
