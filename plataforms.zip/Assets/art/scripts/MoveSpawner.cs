using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveSpawner : MonoBehaviour
{
    // Start is called before the first frame update
 public GameObject objective;
    public GameObject objectmove;

    public void MoveSpawn()
    {
        Vector3 newposition = objective.transform.position;
        
        objectmove.transform.position = newposition;
    }

}
