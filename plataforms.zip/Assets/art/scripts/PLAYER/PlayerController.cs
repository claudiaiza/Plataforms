using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

    public bool grounded;
    public LayerMask groundLayer;
    public float jumpSpeed;
    private MovementBehavior _mvb;
    public Transform _spawn;
    private Animator _anim;
    private SpriteRenderer _spr;
    private Vector3 dir;
    
    // Start is called before the first frame update
    void Start()
    {
       
        _mvb = GetComponent<MovementBehavior>();
        _anim = GetComponent<Animator>();
        _spr = GetComponent<SpriteRenderer>();
        gameObject.transform.SetPositionAndRotation(_spawn.transform.position, _spawn.transform.rotation);
    }

    // Update is called once per frame
    void Update()
    {

        Vector3 newPosition = transform.position;
        newPosition.z = 0;
        transform.position = newPosition;

        dir = new Vector3(Input.GetAxis("Horizontal"), 0, 0);

        // _spr.flipX = true;

        if(Input.GetKeyDown(KeyCode.Space) && grounded == true)
        {
            // Transform.localScale = new Vector3(-1*Transform.localScale.x,Transform.localScale.y, Transform.localScale.z);
            _mvb.Jump(jumpSpeed);
        }

        if(Input.GetKeyDown(KeyCode.A))
        {
            _spr.flipX = true;
        }
        
        if(Input.GetKeyDown(KeyCode.D))
        {
            _spr.flipX = false;
        }

       

        if(dir.x!= 0)
        {
            _anim.SetInteger("state", 1);
        }

        if(!Input.anyKey)
        {
            _mvb.StopMovement();
            _anim.SetInteger("state", 0);
        }

        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.down, 1.0f, groundLayer);


        if(hit)
        {
            grounded = true;
        }

        else
        {
            grounded = false;
        }
    }


    private void FixedUpdate()
    {
        _mvb.MoveRB(dir);
    }

    public void Respawn()
    {
        // gameObject.transform.SetPositionAndRotation(_spawn.transform.position, _spawn.transform.rotation);
        // _anim.SetInteger("state", 0);

        gameObject.transform.SetPositionAndRotation(_spawn.transform.position, _spawn.transform.rotation);
       

    }

 

}
