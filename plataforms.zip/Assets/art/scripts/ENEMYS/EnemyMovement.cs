using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{

    public Transform LeftLimit;
    public Transform RightLimit;
    public float speed;
    private bool active;
    private int direction = -1;

    private bool position = true;
    // Start is called before the first frame update

    void Start()
    {
        active=false;
    }
    // Update is called once per frame
    void Update()
    {

        if(active)
        {
            if (transform.position.x >= RightLimit.position.x)
            {
                if(position)
                {
                    spritedirection();
                }

                direction = 1; // Cambiar dirección del movimiento
            // transform.localScale = new Vector3(-1, 1, 1);
            }
            else if (transform.position.x <= LeftLimit.position.x)
            {
                if(!position)
                {
                    spritedirection();
                }

                direction = -1;
            
            // transform.localScale = new Vector3(1, 1, 1);
            }

            
            transform.Translate(new Vector3(direction * speed * Time.deltaTime, 0f, 0f));
            }
        
    }

    void spritedirection()
    {
        position = !position;
        Vector3 escala = transform.localScale;
        escala.x *= -1;
        transform.localScale = escala;
    }

    public void StopSpawner()
    {
        active=false;
    }

    public void StartSpawner()
    {
        active = true;
    }
}
