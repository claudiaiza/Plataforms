using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;


public class DoorController : MonoBehaviour
{
    private Animator doorAnim;
    public GameObject objectCoins;
    public UnityEvent OnOpened;
    public UnityEvent OnNextLevel;
    public Transform Nextlevel;
    public Transform StartPlay;
    

    // Start is called before the first frame update
    void Start()
    {
        doorAnim = GetComponent<Animator>();
        objectCoins = GameObject.Find("group");
    }

    // Update is called once per frame
    void Update()
    {
        if (objectCoins.transform.childCount == 0)
        {
            doorAnim.SetInteger("state", 1);
            
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {

        Camera.main.transform.SetPositionAndRotation(Nextlevel.transform.position, Nextlevel.transform.rotation);
        GameObject player = GameObject.Find("PLAYER");

        player.transform.SetPositionAndRotation(StartPlay.transform.position, StartPlay.transform.rotation);

            

        OnNextLevel.Invoke();
        
    }

}
