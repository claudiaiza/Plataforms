using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using TMPro;

public class CoinController : MonoBehaviour
{
   public GameObject Door;

   private static int totalCoins;

   public static Action OnCoinDies = delegate { };

   public TextMeshProUGUI coinsText;

   public AudioClip coinSound;

   public GameObject player;
    

    
    private void Start ()
    {
        totalCoins = 0 ;
        coinsText = GameObject.Find("CoinsText").GetComponent<TextMeshProUGUI>();
        UpdateCoinsText();
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
      
        totalCoins++;
            
        AudioSource.PlayClipAtPoint(coinSound, transform.position);

        gameObject.SetActive(false);

        if (totalCoins == 3)
        {
            Door.SetActive(true);
    
        }

        UpdateCoinsText();


        if (player != null && player.GetComponent<HealthBehavior>() != null)
        {
            if (player.GetComponent<HealthBehavior>().IsDead)
            {
                Resetcoins();
            }
        }
    }

  

    public void Resetcoins()
    {
        totalCoins = 0;
        UpdateCoinsText();
    }

    private void UpdateCoinsText()
    {
        coinsText.text = "Coins: " + totalCoins.ToString();
    }

}
