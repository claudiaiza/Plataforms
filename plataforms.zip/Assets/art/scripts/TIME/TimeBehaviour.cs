using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class TimeBehaviour : MonoBehaviour
{

    private float time;
    public bool countDown;
    public float initaltime;
    private float timemood;
    public UnityEvent<float> OnTime;
    public UnityEvent OnTimeOut;

    // Start is called before the first frame update
     void Start()
    {
        RestartTime();
        timemood = 0;
    }

   public void RestartTime()
    {
        time= initaltime;
        OnTime.Invoke(time);
        timemood = 1;
    } 

    public void StartTime()
    {
        timemood = 1;
    }

    public void endtime()
    {
        timemood = 0;
    }
    // Update is called once per frame
    void Update()
    { 

        if(timemood ==1)
        {
            if (countDown)
            {
                time -= Time.deltaTime;
                if(time <=0)
                OnTimeOut.Invoke(); 
            }

            else
            {
                time += Time.deltaTime;
                OnTime.Invoke(time);
            }

            OnTime.Invoke(time);
        }
        
    }
}
