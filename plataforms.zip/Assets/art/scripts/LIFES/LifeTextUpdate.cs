using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class LifeTextUpdate : MonoBehaviour
{
    // Start is called before the first frame update
    public void SetLifestext(float lifes)
    {
        GetComponent<TMP_Text>().text="Lifes:"+lifes;
    }
}
